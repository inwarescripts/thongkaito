export const state = {
    loading: false
}

export const mutations = {
    set_loading(state, loading) {
        state.loading = loading
    }
}
