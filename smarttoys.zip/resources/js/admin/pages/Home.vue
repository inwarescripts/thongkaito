<template>
    <div class="wrap">
        Dashboard
        <loading></loading>
    </div>
</template>
<script>

    export default {
        components: {
        },
        props: {
        },
        data() {
            return {

            }
        },
        methods: {
        }
    }
</script>