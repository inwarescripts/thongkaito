import Vue from 'vue'
import Loading from './Loading'

Vue.component('Loading', Loading)
