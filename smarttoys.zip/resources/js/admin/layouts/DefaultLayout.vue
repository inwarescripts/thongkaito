<template>
    <router-view></router-view>
</template>

<script>
    export default {
        mounted() {
            console.log('admin');
        }
    }
</script>